/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_checkeratoi.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 02:42:09 by henix             #+#    #+#             */
/*   Updated: 2025/01/11 15:08:28 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

int	ft_isdigit(int c)
{
	return (c >= '0' && c <= '9');
}

int	ft_strisdigit(char *str)
{
	int	i;
	int	re_value;

	i = 0;
	re_value = 1;
	if (!str[i])
		return (0);
	while (str[i])
	{
		re_value = ft_isdigit(str[i]);
		if (re_value == 0)
			break ;
		i++;
	}
	return (re_value);
}

long	ft_atoi(char *str)
{
	long	i;
	int		sign;
	long	res;

	i = 0;
	sign = 1;
	res = 0;
	if (str[i] == '+' || str[i] == '-')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	if (ft_strisdigit(str + i) == 0)
		return (E_FLAG);
	while (str[i])
	{
		res = res * 10 + (str[i] - '0');
		i++;
	}
	res = res * sign;
	if (res > INT_MAX || res < INT_MIN)
		return (E_FLAG);
	return (res);
}
