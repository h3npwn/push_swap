/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/25 10:22:16 by abahja            #+#    #+#             */
/*   Updated: 2025/01/11 15:07:42 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	char	*destx;
	char	*srcx;

	srcx = (char *)src;
	destx = (char *)dest;
	if (!destx && !srcx)
		return (NULL);
	while (n--)
	{
		*destx = *srcx;
		destx++;
		srcx++;
	}
	return (dest);
}
