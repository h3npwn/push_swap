/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap_m.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/22 14:27:59 by abahja            #+#    #+#             */
/*   Updated: 2025/01/22 14:42:09 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static int	swap(t_list **head)
{
	t_list	*tmp;
	void	*s[3];
	int		i;

	i = 0;
	if (ft_lstsize(*head) < 2)
		return (-1);
	tmp = *head;
	while (3 > i)
	{
		s[i++] = tmp;
		if (tmp != NULL)
			tmp = tmp->next;
	}
	*head = s[1];
	(*head)->next = s[0];
	(*head)->next->next = s[2];
	return (0);
}

int	sa(t_list **stack)
{
	if (swap(stack) == -1)
		return (-1);
	ft_putstr_fd("sa\n", 1);
	return (0);
}
