/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/11 16:45:38 by abahja            #+#    #+#             */
/*   Updated: 2025/01/30 13:37:31 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

int	main(int ac, char **av)
{
	t_list	*stack_a;
	t_list	*stack_b;

	if (ac > 2)
	{
		stack_a = NULL;
		stack_b = NULL;
		ft_init(&stack_a, av);
		if (!stack_a)
		{
			write(2, "malloc :error in intialization stack", 37);
			exit(1);
		}
		assign_rank(&stack_a);
		if (!is_sorted(&stack_a))
		{
			if (ft_lstsize(stack_a) <= 5)
				simple_sort(&stack_a, &stack_b);
			else
				radix_sort(&stack_a, &stack_b);
		}
		ft_lstclear(&stack_a, free);
	}
	return (0);
}
