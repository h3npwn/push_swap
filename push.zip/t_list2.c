/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   t_list2.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/26 13:48:02 by abahja            #+#    #+#             */
/*   Updated: 2025/01/19 16:34:02 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	ft_lstdelone(t_list *lst, void (*del)(void*))
{
	if (!lst || !del)
		return ;
	del(lst);
}

int	ft_lstlastmagic(t_list *head, t_list **node, t_list *new)
{
	t_list	*tmp;

	tmp = head;
	while (tmp->next)
	{
		tmp = tmp->next;
		if (new->value == tmp->value)
		{
			return (0);
		}
		if (tmp->next == NULL)
		{
			*node = tmp;
			return (1);
		}
	}
	*node = tmp;
	return (1);
}

void	ft_lstclear(t_list **lst, void (*del)(void*))
{
	t_list	*tempi;

	if (!lst || !del)
		return ;
	while (*lst)
	{
		tempi = (*lst)->next;
		ft_lstdelone(*lst, del);
		*lst = tempi;
	}
	*lst = NULL;
}
