/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/11 13:29:46 by abahja            #+#    #+#             */
/*   Updated: 2025/01/30 13:37:40 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

static void	free_split(char **split)
{
	int	i;

	i = 0;
	while (split[i])
		free(split[i++]);
	free(split);
}

int	ft_dropdata(t_list **stack_a, char **buffer)
{
	long	value;
	int		status;
	int		i;
	t_list	*tmp;

	i = 0;
	status = 1;
	while (buffer[i])
	{
		value = ft_atoi(buffer[i]);
		if (value == E_FLAG)
			(ft_lstclear(stack_a, free), ft_putstr_fd("error\n", 2)
				, free_split(buffer), exit(1));
		tmp = ft_lstnew(value);
		if (tmp == NULL)
			return (0);
		status = ft_lstadd_back(stack_a, tmp, 'c');
		if (status == 0)
			(ft_lstclear(stack_a, free), ft_putstr_fd("error\n", 2)
				, free_split(buffer), free(tmp), exit(1));
		i++;
	}
	return (0);
}

int	ft_init(t_list **stack_a, char **av)
{
	char	**buffer;
	int		i;

	i = 1;
	if (!av[1])
		return (1);
	while (av[i])
	{
		buffer = ft_split(av[i], ' ');
		if (buffer == NULL)
			return (0);
		ft_dropdata(stack_a, buffer);
		free_split(buffer);
		i++;
	}
	return (0);
}
