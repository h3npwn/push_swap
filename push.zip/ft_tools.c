/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tools.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/01/22 14:32:52 by abahja            #+#    #+#             */
/*   Updated: 2025/01/22 14:38:47 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	assign_rank(t_list **stack_a)
{
	int		rank;
	t_list	*tmp_1;
	t_list	*tmp_2;

	tmp_1 = *stack_a;
	while (tmp_1 != NULL)
	{
		rank = 0;
		tmp_2 = *stack_a;
		while (tmp_2 != NULL)
		{
			if (tmp_1->value > tmp_2->value)
				rank += 1;
			tmp_2 = tmp_2->next;
		}
		tmp_1->rank = rank;
		tmp_1 = tmp_1->next;
	}
}

int	is_sorted(t_list **stack)
{
	t_list	*tmp;
	int		size;

	size = ft_lstsize(*stack);
	if (size < 2)
		return (1);
	tmp = *stack;
	while (tmp->next != NULL)
	{
		if (tmp->value > tmp->next->value)
			return (0);
		tmp = tmp->next;
	}
	return (1);
}

int	ft_max(t_list **stack)
{
	int		pivot;
	t_list	*tmp;

	pivot = (*stack)->value;
	tmp = (*stack)->next;
	while (tmp)
	{
		if (pivot < tmp->value)
			pivot = tmp->value;
		tmp = tmp->next;
	}
	return (pivot);
}

int	ft_min(t_list **stack)
{
	int		pivot;
	t_list	*tmp;

	pivot = (*stack)->value;
	tmp = (*stack)->next;
	while (tmp)
	{
		if (pivot > tmp->value)
			pivot = tmp->value;
		tmp = tmp->next;
	}
	return (pivot);
}

int	find_index(int target, t_list **stack)
{
	t_list	*tmp;
	int		i;

	i = 0;
	tmp = *stack;
	while (tmp->next)
	{
		if (target == tmp->value)
			break ;
		i++;
		tmp = tmp->next;
	}
	return (i);
}
