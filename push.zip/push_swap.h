/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: abahja <abahja@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/24 13:10:05 by abahja            #+#    #+#             */
/*   Updated: 2025/01/30 13:38:08 by abahja           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdio.h>
# include <stdlib.h>
# include <limits.h>
# include <unistd.h>
# define E_FLAG 4200001337

typedef struct s_list
{
	int				rank;
	int				value;
	struct s_list	*next;
}	t_list;

// functions of list manipulation
t_list	*ft_lstnew(int value);
t_list	*ft_lstlast(t_list *head);
int		ft_lstadd_back(t_list **stack, t_list *new, char flag);
int		ft_init(t_list **stack_a, char **av);
int		ft_lstsize(t_list *head);
int		ft_lstlastmagic(t_list *head, t_list **node, t_list *new);
void	ft_lstadd_front(t_list **stack, t_list *new);
void	ft_lstclear(t_list **lst, void (*del)(void*));
void	ft_lstdelone(t_list *lst, void (*del)(void*));
void	printList(t_list *head);
// functions for error handling 
void	ft_putchar_fd(char c, int fd);
void	ft_putstr_fd(char *s, int fd);
/*----------------------------------*/
char	**ft_split(const char *s, char c);
char	*ft_substr(char const *s, unsigned int start, size_t len);
char	*ft_strdup(const char *s);
void	*ft_memcpy(void *dest, const void *src, size_t n);
size_t	ft_strlen(const char *s);
long	ft_atoi(char *str);
// functions for sorting stack
/*----------------------------------*/
int		sa(t_list **stack_a);
int		pa(t_list **stack_a, t_list **stack_b);
int		pb(t_list **stack_a, t_list **stack_b);
int		ra(t_list **stack_a);
int		rra(t_list **stack_a);
/*------------------------------*/
void	assign_rank(t_list **stack_a);
int		is_sorted(t_list **stack);
int		sort_under3(t_list **stack_a);
int		ft_min(t_list **stack);
int		ft_max(t_list **stack);
int		find_index(int target, t_list **stack);
void	ft_sort(t_list **stack_a);
void	sort_3(t_list **stack_a);
void	sort_4(t_list **stack_a, t_list **stack_b);
void	sort_5(t_list **stack_a, t_list **stack_b);
void	simple_sort(t_list **stack_a, t_list **stack_b);
void	radix_sort(t_list **stack_a, t_list **stack_b);
#endif